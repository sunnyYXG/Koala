//
//  DataModels.h
//
//  Created by   on 17/3/30
//  Copyright (c) 2017 __MyCompanyName__. All rights reserved.
//

#import "Body.h"#import "Home.h"#import "LocationInfo.h"#import "BannerList.h"#import "ItemList.h"#import "BaseClass.h"