//
//  navBarHandleModel.h
//  Kaola
//
//  Created by rongyun on 17/5/8.
//  Copyright © 2017年 YXGang. All rights reserved.
//

#import <Foundation/Foundation.h>
@class KLNavBar;
@interface navBarHandleModel : NSObject

+ (NSArray *)navBarHandleModel:(KLNavBar *)baseModel;

@end
