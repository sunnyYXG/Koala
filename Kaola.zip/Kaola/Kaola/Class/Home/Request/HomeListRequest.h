//
//  HomeListRequest.h
//  Kaola
//
//  Created by sunny_FX on 2017/3/30.
//  Copyright © 2017年 YXGang. All rights reserved.
//

#import "BaseRequest.h"

@interface HomeListRequest : BaseRequest

/** 参数 */
+ (NSDictionary *)params;

+ (NSDictionary *)paramsWithPageNo:(NSInteger)pageNo;

@end
