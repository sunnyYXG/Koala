//
//  navBarRequest.h
//  Kaola
//
//  Created by rongyun on 17/5/8.
//  Copyright © 2017年 YXGang. All rights reserved.
//

#import "BaseRequest.h"

@interface navBarRequest : BaseRequest

+ (NSDictionary *)params;

@end
