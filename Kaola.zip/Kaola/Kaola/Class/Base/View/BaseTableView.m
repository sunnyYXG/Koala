//
//  BaseTableView.m
//  Kaola
//
//  Created by rongyun on 17/3/28.
//  Copyright © 2017年 YXGang. All rights reserved.
//

#import "BaseTableView.h"

@implementation BaseTableView

@end
