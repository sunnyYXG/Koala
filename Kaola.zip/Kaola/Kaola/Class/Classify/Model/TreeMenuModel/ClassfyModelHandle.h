//
//  ClassfyModelHandle.h
//  Kaola
//
//  Created by rongyun on 17/4/25.
//  Copyright © 2017年 YXGang. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ClassfyModelHandle : NSObject

+(NSArray *)ClassfyModelHandle:(NSArray *)datas;


@end
