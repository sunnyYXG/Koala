//
//  DataModels.h
//
//  Created by   on 17/5/3
//  Copyright (c) 2017 __MyCompanyName__. All rights reserved.
//

#import "ForYouCategory.h"#import "ForYouCommonCategoryList.h"#import "ForYouBrandList.h"#import "ForYouTopBanner.h"#import "ForYouHotCategoryList.h"#import "ForYouBody.h"#import "ForYouAlbumList.h"