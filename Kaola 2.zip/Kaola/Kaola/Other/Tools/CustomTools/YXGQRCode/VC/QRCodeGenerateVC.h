//
//  QRCodeGenerateVC.h
//  SGQRCodeExample
//
//  Created by Sorgle on 16/8/25.
//  Copyright © 2016年 Sorgle. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface QRCodeGenerateVC : UIViewController

@end
