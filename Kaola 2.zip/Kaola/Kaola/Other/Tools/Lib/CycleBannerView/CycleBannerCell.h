//
//  CycleBannerCell.h
//  CycleScrollView
//  Kaola
//
//  Created by rongyun on 17/3/31.
//  Copyright © 2017年 YXGang. All rights reserved.

#import <UIKit/UIKit.h>

@interface CycleBannerCell : UICollectionViewCell

- (void)setCellDataWithUrl:(NSString *)imgUrl;

@end
