//
//  BaseTableView.h
//  Kaola
//
//  Created by rongyun on 17/3/28.
//  Copyright © 2017年 YXGang. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BaseTableView : UITableView

@end
