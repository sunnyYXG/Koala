//
//  YXGFindVideoChildVC.h
//  Kaola
//
//  Created by rongyun on 17/5/11.
//  Copyright © 2017年 YXGang. All rights reserved.
//

#import "BaseTableViewController.h"

@interface YXGFindVideoChildVC : BaseTableViewController

@end
