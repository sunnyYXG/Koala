//
//  FindViewController.m
//  YXGDemo
//
//  Created by sunny_FX on 2017/3/25.
//  Copyright © 2017年 YXG. All rights reserved.
//

#import "YXGFindViewController.h"
#import "YXGFindBuyChildVC.h"
#import "YXGFindVideoChildVC.h"

@interface YXGFindViewController ()<UIScrollViewDelegate>

@property (nonatomic, strong) UISegmentedControl *segmentedControl;
@property (nonatomic, strong) UIScrollView *scrollView;
@property (nonatomic, strong) YXGFindBuyChildVC *firstVC;
@property (nonatomic, strong) YXGFindVideoChildVC *secondTVC;

@end

@implementation YXGFindViewController


- (void)viewDidLoad {
    [super viewDidLoad];
    [self addERCodeSearchNavBar:NavBarViewType ERcodeSearchType:ERcodeAndMessageType];

    WeakSelf(weakSelf)
    self.ERcodeSearchView.SegmentClickIndexBlock = ^(NSInteger index){
        [weakSelf segmentedControlAction:index - 100];
    };
    // 适应scrollView
    self.automaticallyAdjustsScrollViewInsets = NO;
    
    /*
    self.segmentedControl = [[UISegmentedControl alloc] initWithItems:@[@"first", @"second"]];
    self.navigationItem.titleView = self.segmentedControl;
    [self.segmentedControl addTarget:self action:@selector(segmentedControlAction:) forControlEvents:UIControlEventValueChanged];
    self.segmentedControl.selectedSegmentIndex = 0;
    self.segmentedControl.tintColor = [UIColor blackColor];
     */
    
    // 创建scrollView
    self.scrollView = [[UIScrollView alloc] initWithFrame:CGRectMake(0, 64, [UIScreen mainScreen].bounds.size.width, [UIScreen mainScreen].bounds.size.height - 64)];
    [self.view addSubview:self.scrollView];
    // 设置scrollView的内容
    self.scrollView.contentSize = CGSizeMake([UIScreen mainScreen].bounds.size.width * 2, [UIScreen mainScreen].bounds.size.height - 64);
    self.scrollView.pagingEnabled = YES;
    self.scrollView.bounces = NO;
    
    // 创建控制器
    self.firstVC = [YXGFindBuyChildVC new];
    self.secondTVC = [YXGFindVideoChildVC new];
    // 添加为self的子控制器
    [self addChildViewController:self.firstVC];
    [self addChildViewController:self.secondTVC];
    self.firstVC.view.frame = CGRectMake(0, 0, self.scrollView.frame.size.width, CGRectGetHeight(self.scrollView.frame));
    self.secondTVC.view.frame = CGRectMake([UIScreen mainScreen].bounds.size.width, 0, self.scrollView.frame.size.width, CGRectGetHeight(self.scrollView.frame));
    [self.scrollView addSubview:self.firstVC.view];
    [self.scrollView addSubview:self.secondTVC.view];
    
    // 设置scrollView的代理
    self.scrollView.delegate = self;

    // Do any additional setup after loading the view.
}

- (void)segmentedControlAction:(NSInteger)index
{
    [self.scrollView setContentOffset:CGPointMake(index * self.scrollView.frame.size.width, 0) animated:NO];
}

- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView
{
    NSInteger n = scrollView.contentOffset.x / scrollView.frame.size.width;
    self.segmentedControl.selectedSegmentIndex = n;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
