//
//  YXGSegmentView.m
//  Kaola
//
//  Created by rongyun on 17/5/11.
//  Copyright © 2017年 YXGang. All rights reserved.
//

#import "YXGSegmentView.h"

@implementation YXGSegmentView

-(id)initWithFrame:(CGRect)frame title:(NSArray *)title tags:(NSArray *)tags{
    self = [super initWithFrame:frame];
    if (self) {
        [self createView:title tags:tags];
    }
    return self;
}

- (void)createView:(NSArray *)title tags:(NSArray *)tags{
    for (NSInteger i = 0; i <title.count; i ++) {
        UIButton *btn = [[UIButton alloc]initWithFrame:CGRectMake(i * (self.width/title.count), 0, self.width/2, 40)];
        [btn setTitle:title[i] forState:UIControlStateNormal];
        btn.selected = NO;
        [btn addTarget:self action:@selector(btn:) forControlEvents:UIControlEventTouchUpInside];
        [btn setTitleColor:UIColorFromRGBValue(0x4A4A4A) forState:UIControlStateNormal];
        [btn.titleLabel setFont:[UIFont systemFontOfSize:16.0f]];
        
        
        UIView *view = [[UIView alloc]initWithFrame:CGRectMake(btn.left, btn.bottom, btn.width, 2)];
        view.backgroundColor = UIColorFromRGB(240, 240, 240);
        
        btn.tag = [tags[i] integerValue];
        view.tag = btn.tag + 1000;
        
        
        [self addSubview:btn];
        [self addSubview:view];
        view.hidden = NO;
        
        if (i == 0) {
            view.backgroundColor = UIColorFromRGBValue(0xFDAF00);
            btn.selected = YES;
            self.lastBtn = btn;
        }
    }
    
}

-(void)btn:(UIButton *)sender{
    
    if (!sender.selected) {
        self.lastBtn.selected = NO;
        UIView *lastView = (UIView *)[self viewWithTag:self.lastBtn.tag + 1000];
        lastView.backgroundColor = UIColorFromRGB(240, 240, 240);
        sender.selected = YES;
        UIView *selectView = (UIView *)[self viewWithTag:sender.tag + 1000];
        self.lastBtn = sender;
        selectView.backgroundColor = UIColorFromRGBValue(0xFDAF00);
        
    }
    
    if ([self.delegate respondsToSelector:@selector(YXGSegmentViewDelegateRefreshData:)]) {
        [self.delegate YXGSegmentViewDelegateRefreshData:sender];
    }
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
