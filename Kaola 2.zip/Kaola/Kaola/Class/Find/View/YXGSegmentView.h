//
//  YXGSegmentView.h
//  Kaola
//
//  Created by rongyun on 17/5/11.
//  Copyright © 2017年 YXGang. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol YXGSegmentViewDelegate <NSObject>

- (void)YXGSegmentViewDelegateRefreshData:(UIButton *)sender;

@end

@interface YXGSegmentView : UIView

@property (nonatomic)id<YXGSegmentViewDelegate>delegate;
-(id)initWithFrame:(CGRect)frame title:(NSArray *)title tags:(NSArray *)tags;

@property (nonatomic)UIButton *lastBtn;

@end
