//
//  ERcodeSearchView.h
//  Kaola
//
//  Created by rongyun on 17/5/11.
//  Copyright © 2017年 YXGang. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "YXGSegmentView.h"
typedef void (^ERcodeSearchViewBlock)(UIViewController *Ctr);
typedef void (^ERcodeSearchViewBlockPresent)(UIViewController *AlertCtr);
typedef void (^SegmentClickIndex)(NSInteger index);
typedef NS_ENUM(NSInteger,ERcodeSearchType) {
    ERcodeAndSearchType = 1,
    ERcodeAndMessageType = 2,

};


@interface ERcodeSearchView : UIView<UISearchBarDelegate,YXGSegmentViewDelegate>

@property (strong, nonatomic) UISearchBar *searchBar;
@property (strong, nonatomic) UIButton *ERCodeBtn;

@property (nonatomic, copy) ERcodeSearchViewBlock SearchPushBlock;
@property (nonatomic, copy) ERcodeSearchViewBlockPresent ERcodePresentBlock;
@property (nonatomic, copy) SegmentClickIndex SegmentClickIndexBlock;

@property (nonatomic)YXGSegmentView *SegmentView;


-(void)configureViewWithType:(ERcodeSearchType)type;
@end
