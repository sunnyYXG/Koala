//
//  ClassfyDataModels.h
//
//  Created by   on 17/4/24
//  Copyright (c) 2017 __MyCompanyName__. All rights reserved.
//

#import "ClassfyModel.h"
#import "ClassfyCategoryTreeMenuList.h"
#import "ClassfyBody.h"
