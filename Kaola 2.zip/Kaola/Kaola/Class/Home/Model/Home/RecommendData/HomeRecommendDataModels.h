//
//  DataModels.h
//
//  Created by   on 17/5/9
//  Copyright (c) 2017 __MyCompanyName__. All rights reserved.
//

#import "RecommendBody.h"#import "RecommendBase.h"#import "RecommendAlbumGoodsList.h"#import "RecommendGoodsPropertyList.h"#import "RecommendLocationInfo.h"#import "RecommendPropertyValues.h"#import "RecommendSkuPropertyList.h"#import "RecommendHome.h"#import "RecommendSkuGoodsPropertyList.h"#import "RecommendCommentPreview.h"#import "RecommendZhengdanActivity.h"#import "RecommendSkuList.h"