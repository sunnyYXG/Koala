//
//  YXGHomeOtherController.h
//  YXGDemo
//
//  Created by sunny_FX on 2017/3/25.
//  Copyright © 2017年 YXG. All rights reserved.
//

#import "BaseTableViewController.h"

@interface YXGHomeOtherController : BaseTableViewController
@property (nonatomic , copy) NSString *content;

@end
